function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5mtHcIXLhGK":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

